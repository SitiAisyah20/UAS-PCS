package com.pcs.apptoko.response.supplier

data class SupplierResponse(
    val `data`: Data,
    val message: String,
    val success: Boolean
)