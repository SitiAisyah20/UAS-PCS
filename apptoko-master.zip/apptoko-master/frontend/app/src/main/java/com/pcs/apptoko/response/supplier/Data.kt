package com.pcs.apptoko.response.supplier

data class Data(
    val supplier: List<Supplier>
)
